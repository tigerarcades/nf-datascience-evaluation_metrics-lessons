# Classification Metrics in Scikit-Learn
In this tutorial, we practice using the classification metrics in Python's scikit-learn. 

This tutorial was based on sklearn version 0.19.1
 